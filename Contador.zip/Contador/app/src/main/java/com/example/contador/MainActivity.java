package com.example.contador;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private Button buttonSumar;
    private Button buttonRestar;
    private Button buttonReset;
    private TextView textviewResultado;
    private CheckBox checkbox;
    private EditText editTextNumero;
    private int resultado;
    private int operador;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonSumar = (Button) findViewById(R.id.buttonSumar);
        buttonSumar.setOnClickListener(this);
        buttonRestar = (Button) findViewById(R.id.buttonRestar);
        buttonRestar.setOnClickListener(this);
        buttonReset = (Button) findViewById(R.id.buttonReset);
        buttonReset.setOnClickListener(this);
        textviewResultado = (TextView) findViewById(R.id.textViewResultado);
        checkbox = (CheckBox) findViewById(R.id.checkBox);
        editTextNumero = (EditText) findViewById(R.id.editTextNumero);

    }


    @Override
    public void onClick(View v) {

        resultado = (int) Integer.parseInt((String) textviewResultado.getText());
        switch (v.getId()) {
            case R.id.buttonSumar:

                operador = 1;
                resultado = resultado + operador;
                String s = Integer.toString(resultado);
                textviewResultado.setText(s);
                break;
            case R.id.buttonReset:
                s = "0";
                textviewResultado.setText(s);
                editTextNumero.setText("");
                break;

            case R.id.buttonRestar:

                if (checkbox.isChecked() && !editTextNumero.getText().toString().isEmpty()) {


                    operador = Integer.parseInt(editTextNumero.getText().toString());
                    resultado = resultado - operador;

                    textviewResultado.setText(Integer.toString(resultado));
                    editTextNumero.setText("");
                } else if (!checkbox.isChecked() && !editTextNumero.getText().toString().isEmpty()) {
                    operador = Integer.parseInt(editTextNumero.getText().toString());
                    ;
                    resultado = resultado - operador;
                    if (resultado >= 0) {
                        textviewResultado.setText(Integer.toString(resultado));
                        editTextNumero.setText("");

                    } else {
                        Toast.makeText(this, "no se adminten negativos", Toast.LENGTH_SHORT).show();
                        editTextNumero.setText("");
                    }

                } else if (!checkbox.isChecked() && editTextNumero.getText().toString().isEmpty()) {
                    textviewResultado.setText(Integer.toString(resultado));
                    operador = 1;
                    resultado = resultado - operador;
                    if (resultado >= 0) {

                        textviewResultado.setText(Integer.toString(resultado));
                    } else {
                        Toast.makeText(this, "no se adminten negativos", Toast.LENGTH_SHORT).show();

                    }
                }default:
        }








                }

        }



